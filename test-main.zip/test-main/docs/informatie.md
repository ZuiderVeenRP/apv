# **Informatie:**<br>

### **Aanvechten straf binnen bepaalde tijd aanmaken om behandeld te worden.**<br>
Een burger heeft het recht om in beroep te gaan tegen de opgelegde straf. Dit dient enkel binnen een tijdsbestek van 1 week te gebeuren. Na dit tijdsbestek valt er niet meer in beroep te gaan tegen uw opgelegde straf.<br>
</br>

### **Refunds claimen binnen een bepaalde tijd.**<br>
Een refund dient binnen 2 weken geclaimd te zijn, anders zal de verkregen refund vervallen, tenzij er een afspraak is gemaakt met het stafflid in kwestie over het claimen op een later moment.<br>
</br>

### **Veranderingen straf afhankelijk scenario verwoorden.**<br>
Indien er duidelijk bewijs gevonden is die de opgelegde straf kan veranderen, staat het stafflid in zijn recht om de straf te veranderen. Dit is afhankelijk van het gevonden bewijs.<br>
</br>

### **Omzeilen straf.**<br>
Het omzeilen van een opgelegde straf is  verboden. Indien dit geconstateerd wordt volgt een straf opleggen van de 9e categorie.<br>
Proberen ‘’loopholes’’ te vinden in de regels en/of de regels te misbruiken/buigen voor je eigen voordeel is niet toegestaan en zal worden bestraft volgens categorie 7.<br>
</br>

### **Bans zijn op GTA license en IP verbonden.**<br>
Bans worden uitgedeeld op GTA License en IP-Adres en geldt dus voor een ieder die hier gebruik van maakt. Dit geldt ook voor familieleden of vrienden in hetzelfde huis. Hier dien je samen verantwoordelijk voor te zijn, mocht iemand een straf krijgen.<br>
</br>

### **Straffen worden verhoogd na herhaling.**<br>
Wanneer je dezelfde categorie meerdere keren heb gehad kan je volgende straf verhoogd worden met 1 categorie.<br>
</br>

### **Tonen bewijsmateriaal.**<br>
Een stafflid is niet verplicht om verzameld bewijsmateriaal te tonen aan een speler, wanneer hij/zij een straf heeft gekregen na het overtreden van een/of meerdere regels.<br>
</br>

### **Klacht maken over een speler.**<br>
Een klacht over een speler dient binnen een week aangemaakt te worden. Daarna zal het niet meer bekeken worden door een stafflid in kwestie.

